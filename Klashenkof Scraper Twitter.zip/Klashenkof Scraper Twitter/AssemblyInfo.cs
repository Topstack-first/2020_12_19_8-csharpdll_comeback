﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: ComVisible(false)]
[assembly: AssemblyDescription("")]
[assembly: Guid("6ccf6c08-5995-46bc-ad8a-9407a608bf84")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyProduct("Klashenkof Scraper Twitter")]
[assembly: AssemblyTitle("Klashenkof Scraper Twitter")]
[assembly: AssemblyCompany("ToolsRoot.")]
[assembly: AssemblyCopyright("ToolsRoot 2020")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyVersion("1.0.0.0")]
