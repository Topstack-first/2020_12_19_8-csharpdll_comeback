﻿// Decompiled with JetBrains decompiler
// Type: ConfusedByAttribute
// Assembly: Klashenkof Scraper Twitter, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: D6BF0248-110E-4E9E-9859-E792BE5B00D3
// Assembly location: E:\temp\KLF Scraper Twitter\Klashenkof Scraper Twitter.exe

using System;
using System.Runtime.InteropServices;

internal class ConfusedByAttribute : Attribute
{
  public ConfusedByAttribute([In] string obj0)
  {
    // ISSUE: unable to decompile the method.
  }
}
